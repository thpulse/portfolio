package kitri.performinfo.prfplace.dao;

public interface PrfplaceDAO {

	void Add_Prfplace();

}
