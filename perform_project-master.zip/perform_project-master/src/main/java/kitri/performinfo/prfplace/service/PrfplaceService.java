package kitri.performinfo.prfplace.service;

public interface PrfplaceService {

	void Add_Prfplace();

}
