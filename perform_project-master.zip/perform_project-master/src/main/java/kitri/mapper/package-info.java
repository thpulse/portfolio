/**
 * 
 */
/**
 * @author Windows7
 *
 */
package kitri.mapper;