package kitri.stats.service;

import java.util.List;

import kitri.stats.vo.StatsVO;

public interface StatsService {
	List<StatsVO> stats(String userid);
}
