package kitri.stats.dao;

import java.util.List;

import kitri.stats.vo.StatsVO;

public interface StatsDAO {
	List<StatsVO> stats(String userid);
}
