package kitri.stats.controller;

public class StatsController {

}
